@extends('layouts.master')
@section('content')
<div class="container">
    <div class="container-fluid textemp">
        <h1 class="titemp">Titulo qualquer</h1>
        <hr>
        <p class="text-justify">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam consequat et velit sit amet aliquam. Sed molestie interdum ligula, aliquet iaculis leo rutrum at. Etiam blandit arcu a lorem tempus, id dictum arcu porttitor. Integer venenatis dolor a tortor ullamcorper egestas. Integer laoreet sapien non maximus pulvinar. Curabitur non ullamcorper tellus. Morbi cursus erat ut ligula aliquam tempus. Fusce malesuada ligula eu ornare bibendum. Donec purus ligula, venenatis vel libero vel, ultricies tincidunt turpis. Donec at mauris feugiat, sagittis diam ut, tincidunt tortor. Ut pharetra tempus posuere. Nam vitae dolor lacus. Vestibulum eu magna sit amet erat pretium volutpat et et risus.
        </p>
        <p class="text-justify">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam consequat et velit sit amet aliquam. Sed molestie interdum ligula, aliquet iaculis leo rutrum at. Etiam blandit arcu a lorem tempus, id dictum arcu porttitor. Integer venenatis dolor a tortor ullamcorper egestas. Integer laoreet sapien non maximus pulvinar. Curabitur non ullamcorper tellus. Morbi cursus erat ut ligula aliquam tempus. Fusce malesuada ligula eu ornare bibendum. Donec purus ligula, venenatis vel libero vel, ultricies tincidunt turpis. Donec at mauris feugiat, sagittis diam ut, tincidunt tortor. Ut pharetra tempus posuere. Nam vitae dolor lacus. Vestibulum eu magna sit amet erat pretium volutpat et et risus.
        </p>
        <p class="text-justify">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam consequat et velit sit amet aliquam. Sed molestie interdum ligula, aliquet iaculis leo rutrum at. Etiam blandit arcu a lorem tempus, id dictum arcu porttitor. Integer venenatis dolor a tortor ullamcorper egestas. Integer laoreet sapien non maximus pulvinar. Curabitur non ullamcorper tellus. Morbi cursus erat ut ligula aliquam tempus. Fusce malesuada ligula eu ornare bibendum. Donec purus ligula, venenatis vel libero vel, ultricies tincidunt turpis. Donec at mauris feugiat, sagittis diam ut, tincidunt tortor. Ut pharetra tempus posuere. Nam vitae dolor lacus. Vestibulum eu magna sit amet erat pretium volutpat et et risus.
        </p>
        <hr class="linha">
        <hr>
    </div>
</div>
@stop