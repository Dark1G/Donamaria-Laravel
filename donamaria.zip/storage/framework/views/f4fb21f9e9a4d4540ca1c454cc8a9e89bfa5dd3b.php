<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="container-fluid">
        <h1>Lista de Ementas</h1>
        <h4>Lista de ementas registados na base de dados.</h4>
        <a href="<?php echo e(URL::route('pedido.create')); ?>" class="btn btn-default">Voltar a Pedido</a>
        <hr>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Descrição</th>
                        <th>Preço</th>
                        <th>Imagem</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $ementas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ementa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo $ementa->nome; ?></td>
                        <td><?php echo $ementa->descricao; ?></td>
                        <td><?php echo $ementa->preco; ?>€</td>
                        <td>
                            <?php if(is_null($ementa->img)): ?>
                                <img src="<?php echo e(asset('images/untitled-1.png')); ?>" class="adminmenu">
                            <?php else: ?>
                                <img src="<?php echo $ementa->img; ?>" class="adminmenu">
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>