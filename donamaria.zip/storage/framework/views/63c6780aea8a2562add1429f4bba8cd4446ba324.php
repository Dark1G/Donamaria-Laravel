<?php $__env->startSection('content'); ?>
<?php if(Auth::check()): ?>
<div class="container">
    <div class="container-fluid">
        <h1 class="titemp">Escreva um comentário</h1>
        <h4 class="lead subtit">Dê a sua opinião à cerca dos nossos serviços.</h4>
        <a href="<?php echo e(URL::route('comentario.index')); ?>" class="btn btn-default">Voltar atrás</a>
        <hr>

        <form action="<?php echo e(URL::route('comentario.store')); ?>" method="POST">
            <div class="form-group">
                <input type="hidden" id="user" name="user" class="form-control" value="<?php echo e(Auth::id()); ?>">
            </div>
            <div class="form-group">
                <label for="mensagem" class="control-label">Comentário:</label>
                <textarea id="mensagem" name="mensagem" class="form-control" rows="4"></textarea>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-danger" value="Comentar">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            </div>
        </form>
        <hr class="linha">
    </div>
</div>
<?php else: ?>
    <?php echo $__env->make('auth.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>