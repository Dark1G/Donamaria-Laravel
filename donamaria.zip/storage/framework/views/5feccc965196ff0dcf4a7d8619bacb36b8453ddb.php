<!DOCTYPE html>
<html lang="pt">
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Painel de Administração</title>
    <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.png')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
	<script src="<?php echo e(asset('js/jquery-3.1.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
</head>

<body>
	<?php if(Auth::check()): ?>
		<?php if((Auth::user()->perfil ) == 1): ?>
		<header>
			<?php echo $__env->make('layouts.includes.menu2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</header>

		<main class="container">
			<?php echo $__env->yieldContent('content'); ?>
		</main>
		<?php else: ?>
			<script type="text/javascript">
			    window.location = "<?php echo e(route('index')); ?>";
			</script>
		<?php endif; ?>
	<?php else: ?>
		<script type="text/javascript">
			window.location = "<?php echo e(route('login')); ?>";
		</script>
	<?php endif; ?>
</body>
</html>