<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a href="<?php echo e(route('index')); ?>">
                <img class="navbar-brand" src="<?php echo e(asset('images/logo.png')); ?>">
            </a>
            <div class="navbar-right">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
        </div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li class="<?php echo e(Request::is('empresa') ? 'active' : ''); ?>"><a class="qfix" href="<?php echo e(route('empresa')); ?>">A Empresa</a></li>
                <li class="<?php echo e(Request::is('pedido/create') ? 'active' : ''); ?>"><a href="<?php echo e(route('pedido.create')); ?>">Fazer<br>Pedido</a></li>
                <li class="<?php echo e(Request::is('galeria') ? 'active' : ''); ?>"><a href="<?php echo e(route('galeria')); ?>">Fotos<br>e Vídeos</a></li>
                <li class="<?php echo e(Request::is('comentario', 'comentario/create') ? 'active' : ''); ?>"><a href="<?php echo e(route('comentario.index')); ?>">Palavras<br>Doces</a></li>
                <li class="<?php echo e(Request::is('contactos') ? 'active' : ''); ?>"><a class="qfix" href="<?php echo e(route('contactos')); ?>">Contactos</a></li>
                <?php if(Auth::guest()): ?>
                    <li class="dropdown fixl">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button">Login<span class="caret"></span></a>
                        <div id="login-dp" class="row dropdown-menu">
                            <p>Login</p>
                            <div class="col-md-12">
                                <form action="<?php echo e(route('login')); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="form-group">
                                        <input id="email" type="email" class="form-control" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" required autofocus>

                                        <?php if($errors->has('email')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('email')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <input id="password" type="password" class="form-control" name="password" placeholder="Password" required>

                                        <?php if($errors->has('password')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('password')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <div class="checkbox">
                                            <label class="rem">
                                                <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary">
                                            Login
                                        </button>

                                        <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                            Forgot Your Password?
                                        </a>
                                    </div>
                                </form>
                            </div>
                            <div class="bottom text-center">
                                <a href="<?php echo e(route('register')); ?>">Não tem conta?</a>
                            </div>
                        </div>
                    </li>
                <?php else: ?>
                    <li class="dropdown fixl">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                            <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                        </a>

                        <ul class="dropdown-menu" role="menu">
                            <li>
                                <a href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">
                                    Logout
                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>