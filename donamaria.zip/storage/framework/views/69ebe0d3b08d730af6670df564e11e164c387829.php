<?php $__env->startSection('content'); ?>
<?php if(Auth::guest()): ?>
    <?php echo $__env->make('auth.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php else: ?>
<div class="container-fluid">
    <h1>Bem-vindo ao sistema de gestão Dona Maria</h1>
    <h4>Tenha em atenção pois todas as acções que fizer puderão ser permanentes..</h4>
    <hr>
    <div class="row placeholders">
        <div class="placeholder">
            <img src="<?php echo e(asset('images/logo.png')); ?>" class="img-responsive imghome" alt="Generic placeholder thumbnail">
        </div>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>