<?php $__env->startSection('content'); ?>

<?php if(Auth::guest()): ?>
    <?php echo $__env->make('auth.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php else: ?>
<div class="container">
    <div class="container-fluid">
        <h1 class="titemp">Fazer pedido</h1>
        <h4 class="lead subtit">Faça o seu pedido de refeição aqui.</h4>
        <a href="<?php echo e(URL::route('ementa.index')); ?>" class="btn btn-default">Lista de ementas</a>
        <a href="<?php echo e(URL::route('garrafeira.index')); ?>" class="btn btn-default">Lista de Garrafas</a>
        </br>
        </br>
        <a href="<?php echo e(URL::route('pedido.index')); ?>" class="btn btn-default">Os meus pedidos</a>
        <hr>

        <form action="<?php echo e(URL::route('pedido.store')); ?>" method="POST">
            <div class="form-group">
                <input type="hidden" id="user" name="user" class="form-control" value="<?php echo e(Auth::id()); ?>">
            </div>
            <div class="form-group">
                <label for="dia" class="control-label">Dia:</label>
                <input type="date" id="dia" name="dia" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="hora" class="control-label">Hora:</label>
                <input type="time" id="hora" name="hora" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="ementa" class="control-label">Ementa:</label>
                <select id="ementa" name="ementa" class="form-control" required>
                    <?php $__currentLoopData = $ementas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ementa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo $ementa->idEmenta; ?>"><?php echo $ementa->nome; ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="garrafa" class="control-label">Garrafa:</label>
                <select id="garrafa" name="garrafa" class="form-control" required>
                    <?php $__currentLoopData = $garrafas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $garrafa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo $garrafa->idGarrafa; ?>"><?php echo $garrafa->nome; ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-danger" value="Fazer pedido">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            </div>
        </form>
        <hr class="linha">
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>